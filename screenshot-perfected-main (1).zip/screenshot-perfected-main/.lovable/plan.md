# Auditoría CitriControlSAT vs PROMPT-LOVABLE-v3.2

He leído el documento completo (921 líneas) y contrastado con el código actual, rutas, BD, y edge function. Aquí el estado real.

## ✅ Lo que YA está hecho (no tocar)

**Backend / BD**

- Todas las tablas de la spec existen: `partes_diarios`, `production_runs`, `gstock_entries`, `lotes_dia`, `partes_archivos`, `costes_diarios`, `asistencia_diaria`, `box_azules`, `profiles`, `user_roles`.
- RLS correcta en todas (pattern `auth.uid() = user_id OR has_role(..., 'admin')`).
- Enums `app_role`, `parte_estado`, `archivo_tipo` presentes.
- Funciones `has_role`, `handle_new_user`, `set_updated_at`.
- Bucket `partes-archivos` privado.
- Secrets: `GEMINI_API_KEY`, `LOVABLE_API_KEY`, service role, etc.
- Edge function `analizar-parte` con extracción server-side XLSX, fallback a warning, timeouts, idempotencia.

**Frontend**

- Stack correcto (React 18 + Vite + shadcn + TanStack Query + i18n).
- `src/lib/cascade.ts` — fórmula correcta (Z1/Z2 en producción real, `palets_ajustados = brutos − inv_anterior`, semáforo 1%/3%).
- `src/lib/format.ts`, `src/lib/i18n.tsx`.
- Componentes base: `CascadeView`, `KPICard`, `StatusBadge`, `AppLayout`, `ProtectedRoute`, `NavLink`.
- Páginas: `Dashboard`, `PartesList`, `PartDetail`, `Auth`, `NotFound`.

## ❌ Gaps vs spec v3.2

### A. Rutas y páginas faltantes (spec §4)

En `App.tsx` solo están `/`, `/partes`, `/partes/:id`, `/auth`. **Faltan:**

- `/costes/consumos` → `ConsumoCostes.tsx` (página completa con KPIs, charts, form, tabla inline-editable, export XLSX/PDF)
- `/costes/asistencia` → `Asistencia.tsx` (tabla inline-editable, % asistencia)
- `/dsj` → `DSJCalculator.tsx` (calculadora standalone, sin Supabase)

### B. Divergencia de nombres de columna (crítico pero cosmético)

La spec usa nombres distintos a los de la BD real. La BD tiene **ambos** juegos de columnas (legacy + spec-v3.2) — son equivalentes:


| Spec v3.2                       | BD / código actual                                                     |
| ------------------------------- | ---------------------------------------------------------------------- |
| `kg_reciclado_manual`           | `kg_industria_manual`                                                  |
| `kg_podrido_manual`             | `kg_podrido_bolsa_basura`                                              |
| `kg_inventario_final`           | `kg_inventario_sin_alta`                                               |
| `kg_palets_pendientes_anterior` | `kg_inventario_anterior_sin_alta`                                      |
| `kg_mujeres_manual`             | `kg_mujeres_calibrador` (auto) + `kg_mujeres_manual` (existe)          |
| `kg_podrido_calibrador_manual`  | `kg_podrido_calibrador_auto` + `kg_podrido_calibrador_manual` (existe) |


**Decisión recomendada:** NO renombrar. El código ya funciona con los nombres legacy y la BD contiene ambos. Renombrar rompería lo que funciona (regla #1).

### C. Componentes faltantes (spec §9)

- `FilesUploader` (existe inline en `PartDetail`, no como componente reutilizable — aceptable)
- `ExtractedValues` (tabla "Valores extraídos" en `PartDetail`) — **falta**
- `ExportPartesDialog` — **falta**
- Charts en Dashboard: BarChart 14d, LineChart 30d, BarChart mermas — **por revisar**

### D. Librerías de export (spec §10)

- `src/lib/exportPartes.ts` — **falta**
- `src/lib/exportConsumo.ts` — **falta**
- Dependencias: `xlsx`, `jspdf`, `jspdf-autotable` — verificar si están en `package.json`.

### E. Sidebar: navegación incompleta (spec §8.1)

El sidebar debe incluir sección **Costes** (Consumos · Asistencia) y **Calculadora DJPM** en Partes. Actualmente no — verificar `AppLayout.tsx`.

## Plan de afinado — por fases

Plan conservador: tocar lo mínimo necesario, sin reescrituras.

### Fase 1 — Núcleo que falta (alta prioridad)

1. **Página `/dsj**` — `DSJCalculator.tsx`. Standalone, pure client, sin Supabase. Usa `computeCascade` existente. Bajo riesgo.
2. **Página `/costes/consumos**` — `ConsumoCostes.tsx` con TanStack Query (useQuery/useMutation), form RHF+Zod, KPIs, 3 charts Recharts, tabla inline-editable, export XLSX/PDF.
3. **Página `/costes/asistencia**` — `Asistencia.tsx` tabla simple inline-editable.
4. **Rutas + sidebar:** añadir a `App.tsx` y `AppLayout.tsx` las entradas nuevas. Tabs móviles (Dashboard · Partes · Costes).

### Fase 2 — Export & componentes reutilizables

5. `**src/lib/exportPartes.ts**` (3 sheets XLSX + PDF landscape).
6. `**src/lib/exportConsumo.ts**` (XLSX + PDF).
7. `**ExportPartesDialog**` component, integrar en `PartesList` y `PartDetail`.
8. `**ExtractedValues**` component en `PartDetail` (tabla origen IA vs manual con iconos 🟠/👤).

### Fase 3 — Afinado de páginas existentes

9. **Dashboard:** verificar los 3 charts Recharts y los 6 KPIs exactos de la spec (Producción, Palets, Dif. bruta, % Descuadre, Merma total, DSJ).
10. **PartDetail:** verificar 5 tabs completos, especialmente tab Validación.
11. **Auto-estado al guardar:** si `|dsj_pct| > 3%` → `estado = 'Con descuadre'` automáticamente en save (mejora high-priority §15).

### Fase 4 — Mejoras recomendadas (§15 spec)

12. **Dashboard:** LineChart 30d de `% DSJ` con líneas 1% y 3%.
13. **Consumos:** hint `kg/ton` en KPIs usando `kg_produccion_total` del día.
14. **Partes:** botón "Copiar de ayer" para prellenar `kg_palets_pendientes_anterior`.

## Preguntas antes de empezar

1. **Orden:** ¿seguimos Fase 1 → 4, o priorizas algo diferente (p. ej. DSJ primero porque es más fácil y da quick win)?
2. **Nombres de columna legacy vs spec:** ¿confirmas NO renombrar (mantener compatibilidad)?
3. **Calculadora:** la spec la llama `/dsj` pero el sidebar dice "Calculadora DJPM". ¿Ruta `/dsj` con etiqueta "DJPM"?
4. **Alcance ahora:** ¿hago Fase 1 entera en un solo turno o prefieres que haga primero solo `/dsj` para validar estilo/patrón?

Procedimiento: Empieza con fase 1-4, continua, arregla bugs sin preguntarme y preguntame todo lo demás.

Cuando confirmes, cambio a modo build y empiezo.